
import './App.css';
import Header from './Header'
import Home from './Home'
import About from './About'
import Category from './category/Category'
import CategoryDescription  from './category/CategoryDescription';
import Footer from './Footer'
import Error from './Error'

import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom'

const navInfo = [
	{ 'url': '/', 'text': 'Главная' },
	{ 'url': '/about', 'text': 'О сайте' },
	{ 'url': '/category', 'text': 'Категории' },
]

const categoryInfo = [
	{'url' : '/notebook', 'text' : 'Ноутбуки'},
	{'url' : '/monitor', 'text' : 'Мониторы'},
	{'url' : '/cellphone', 'text' : 'Мобильные телефоны'},
]



function App() {
  return (
   <>
   <Router>
   <Header data = {navInfo}/>
    <Routes>
      <Route exact path = "/" element={<Home/>}/>
      <Route path = "/about" element={<About/>}/>
      <Route exact path = "/category" element={<Category data = {categoryInfo}/>}/>
      <Route path = '/category/:CategoryDescription' element={<CategoryDescription/>}/>
      <Route path = '/footer' element={<Footer/>}/>
      <Route path = '*' element={<Error/>}/>
    </Routes>
   </Router>
   </>
  );
}

export default App;
