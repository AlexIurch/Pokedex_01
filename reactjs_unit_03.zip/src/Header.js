import { Link } from "react-router-dom"


function Header (props){
  let info = props.data
  console.log(info)

  const listItem = info.map(item => <li key={item.url}><Link to={item.url}>{item.text}</Link></li>)

    return(
      <>
        <nav>
          <ul>
            {listItem}
          </ul>
        </nav>
      </>
    )
}

export default Header