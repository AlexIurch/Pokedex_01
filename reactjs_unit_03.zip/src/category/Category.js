import { useLocation } from 'react-router-dom'

import { Link } from "react-router-dom"

function Category (props){
    let url = useLocation()
    console.log(url)

    const data = props.data
    console.log(data)

    const listItem = data.map(item=> <li key={item.url}><Link to={url.pathname + item.url}>{item.text}</Link></li>)

    return(
     <>
        <h1>Category</h1>

        <a href="/cat">Назад</a>        
        <ul>
          {listItem}
        </ul>
     </>
    )
}

export default Category