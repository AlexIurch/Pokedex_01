import {useParams} from 'react-router-dom'
import { Link } from "react-router-dom"



function CategoryDescription() {
    const CategoryDescription = useParams();
    console.log(CategoryDescription)

    return (
        <div>
            <Link to="/category">Назад</Link>
            <h1>Category: {CategoryDescription.CategoryDescription}</h1>
        </div>
    )
}

export default CategoryDescription;
